<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'ecomm-winter-2021' );

/** MySQL database username */
define( 'DB_USER', 'root' );

/** MySQL database password */
define( 'DB_PASSWORD', '' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'Cmm-Op.cfsXWh6wME:Xt$7e4JY_MM0^~GW>3 `=a#u[rZ `&^@iaY#G?(D, w1iE' );
define( 'SECURE_AUTH_KEY',  '2}n@&(U=ZEy:c~l7?/2$oPZmxl@T-i^:vKXo$,~nxVVdBBE3~%zeAUs|>=f@s  X' );
define( 'LOGGED_IN_KEY',    ';zl>_Gh^j$Jqx[ 6Ukf2K+D8[MwNhL;]aTnYQVS{c0>B9)Vy.6pi9M:+qu6qV&G<' );
define( 'NONCE_KEY',        'ndq5&}wKQNgp %aLOV@ic.;VvZj 4M~&pu]7Tu R9QpNp*?8pG+.K_dxt`{7afk5' );
define( 'AUTH_SALT',        '-2SmicW$.v-pZ]zTrU`_hZStN0&!1s-#lh*j@/dIqnj1#O+{ |roB79HTD6^-stx' );
define( 'SECURE_AUTH_SALT', 'UFv;D~hwX |F^z3TWC.)oQJQ}9OuQqcQy/e^=,dh#C6_tUemjb8Y@OV2nW)2ui&j' );
define( 'LOGGED_IN_SALT',   '>PSf@~~X,5f/y&<HodF)N((S4>rj?_#f,oC`%3>CJvFY=uJhvouj-+hK1`T`Hr9q' );
define( 'NONCE_SALT',       'JI2oGj>iS@^y~c<sA:qf$/AT{mRy/s^0|]hC{>]zRoK#Tn,+>H]C*;6mZ-%^4qi*' );

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
